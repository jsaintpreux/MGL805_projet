# MGL805_projet
#Projet de fin de session MGL805
#Pour exécuter l'application il faut le déployer sur un serveur web et installer le serveur Json.

**Installation du server json**
Si vous n'avez pas enore nodes.js sur votre ordinateur, il faudra d'abord l'installer pour exécuter la commande suivante:

#npm install -g json-server

#Après avoir installer le package json-server, vous pouvez maitenant démarrer le serveur.

**Utiliser cette commande:**

#npm install -g json-server

#NB: Il est suggéré de vous placer dans un répertoire qui est différent du serveur web afin de faire la séparation des ressources utilisées sur chacun des serveurs

#Veuillez vous rendre dans le répertoire d'installation de json-serveur et copier puis coller le fichier db.json qui se trouver dans la branche master.

**Veuillez maintenant démarrer le serveur json en utilisant cette commande:**

#json-server --watch db.json

#Les différents liens d'accès aux APIs suivants vont apparaitre:

** Resources**

  http://localhost:3000/Defauts
  
  http://localhost:3000/executions
  
  http://localhost:3000/exigences
  
  http://localhost:3000/tests
  
  http://localhost:3000/projects
  
  http://localhost:3000/users
  
  http://localhost:3000/testcategory
  
  http://localhost:3000/Env_exec
  
  http://localhost:3000/message
  
  http://localhost:3000/testCases


