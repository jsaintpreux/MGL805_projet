  //hljs.initHighlightingOnLoad();

      $(document).ready(function() {
        if(isFileAPIAvailable()) {
          $('#files').bind('change', handleDialog);
        }
      });

      function handleDialog(event) {
        var files = event.target.files;
        var file = files[0];

        var fileInfo =`
          <span style="font-weight:bold;">${escape(file.name)}</span><br>
          - FileType: ${file.type || 'n/a'}<br>
          - FileSize: ${file.size} bytes<br>
          - LastModified: ${file.lastModifiedDate ? file.lastModifiedDate.toLocaleDateString() : 'n/a'}
        `;
    //    $('#file-info').append(fileInfo);

        var reader = new FileReader();
        reader.readAsText(file);
        reader.onload = function(event){
          var csv = event.target.result;
          var data1 = $.csv.toObjects(csv);
		  var qtecol=data1[0].length;
		  var qteligne=data1.length;
		  var field_name;
		  var myData=[];
		  var k=0,l=0,m=0,n=0,o=0,p=0,q=0,r=0,s=0,t=0,u=0,v=0,w=0;
		  var id=[];
var statut=[];
var type=[];
var description=[];
var priorite=[];
var version_correction=[];
var progression=[];
var totaux_exec_test=[];
var taux_succes=[];
var exigence_id=[];
var etiquettes=[];
 
field_name=Object.keys(data1[1]);
 
 //data.forEach((obj) => {
  
	  var max_id=60;
	  
//}) 
	  
  var getalltestresult=[];
var myData=[];
var url      = window.location.href; 
url = new URL(url);
var id = url.searchParams.get("sessionid");
var urval_select=url.searchParams.get("select");
 
$('#alltestresult').dataTable().fnClearTable();

func(data1,qteligne);
//alert(data1.length);
getalltestresult=getTestResult();
for (var i = 0; i <getalltestresult.id.length; i++) {
  myData[i] = [
  {
  "id": getalltestresult.id[i],
  "Statut": getalltestresult.statut[i],
  "Type": getalltestresult.type[i],
  "Description": getalltestresult.description[i],
  "Priorité": getalltestresult.priorite[i],
  "Version": getalltestresult.version_correction[i],
  "Progression": getalltestresult.progression[i],
  "Taux succès": getalltestresult.taux_succes[i],
  "Etiquette": getalltestresult.etiquettes[i]
  }
  ];
  
  $('#alltestresult').dataTable().fnAddData(myData[i]);
  }

function func(tab,taille) {
   for (let i = 0; i < taille; i++) {
       makeRequest(tab,i);
   }
   alert('Le fichier a été importé avec succès');
}
function makeRequest(data1,i) {
 
    $.ajax({'async': false,
                   type: "POST",
                   url: 'http://localhost:3000/tests/',
                   data:  data1[i],
         dataType:"json",
                   crossDomain: true,
                   cache: false
         , error: function(c, r, v)  
         { 
           alert("Erreur!!!! Merci de vérifier votre connexion internet");
         
           }	,
       success: function(data) {console.log('');}
     });
}


   

	          }
	 
	
	 
	 
      }
	  

      function getTestResult()
      { 
      var k=0,l=0,m=0,n=0,o=0,p=0,q=0,r=0,s=0,t=0,u=0,v=0,w=0,x=0;
      var id=[];
      var statut=[];
      var type=[];
      var description=[];
      var priorite=[];
      var version_correction=[];
      var progression=[];
      var totaux_exec_test=[];
      var taux_succes=[];
      var exigence_id=[];
      var etiquettes=[];
      var taille=0;
      var field_name=[];
      var testtype=[];
      var count=[];
      var percentagetestcategory=[];
      var val=['PASSED','UNCOVERED','FAILED','NOTRUN'];
      
      $.ajax({'async': false,
                          type: "GET",
                          url: 'http://localhost:3000/testcategory',
                          data: "",
                dataType:"json",
                          crossDomain: true,
                          cache: false,
                          beforeSend: function() {
                              $("#insert").val('Loading...');
                          }
                , error: function(c, r, v)  
                { 
                  alert("Erreur!!!! Merci de vérifier votre connexion internet");
                
                  }	,
                          success: function(data) {
                  data.forEach((obj) => {
        for (const [key, value] of Object.entries(obj)) {
          if (key == 'testtype' ) {
          
          testtype[l]=`${value}`;
              l++;
          }	
          
          }
         
      });
                
                }
                });
        $.ajax({'async': false,
                          type: "GET",
                          url: 'http://localhost:3000/tests/',
                          data: "",
                dataType:"json",
                          crossDomain: true,
                          cache: false,
                          beforeSend: function() {
                              $("#insert").val('Loading...');
                          }
                , error: function(c, r, v)  
                { 
                  alert("Erreur!!!! Merci de vérifier votre connexion internet");
                
                  }	,
                          success: function(data) {
                         taille=data.length; 
      field_name=Object.keys(data[1]);
                
 
                  
                 data.forEach((obj) => {
        for (const [key, value] of Object.entries(obj)) {
          if (key == 'id' ) {
          
          id[k]=`${value}`;
              k++;
          }	
           if (key == 'Status' ) {
          
          statut[m]=`${value}`;
           m++;
          }
          
           if (key == 'Type' ) {
          
          type[n]=`${value}`;
           n++;
          }
        
           if (key == 'Description' ) {
          
          description[o]=`${value}`;
          o++;
          }
           
           if (key == 'Priorite' ) {
          
          priorite[p]=`${value}`;
           p++;
          }
        if (key == 'Version_correction' ) {
          
          version_correction[q]=`${value}`;
           q++;
          }
         if (key == 'Progression' ) {
          
          progression[r]=`${value}`;
           r++;
          }
        if (key == 'Totaux_exec_test' ) {
          
          totaux_exec_test[s]=`${value}`;
           s++;
          }
        if (key == 'Taux_succes' ) {
          
          taux_succes[u]=`${value}`;
           u++;
          }
        if (key == 'exigence_id' ) {
          
          exigence_id[v]=`${value}`;
           v++;
          }
        if (key == 'Etiquettes' ) {
          
          etiquettes[w]=`${value}`;
           w++;
          }
        if (key == 'testtype' ) {
          testtype[w]=`${value}`;
          x++;
                    }
        
          }
         
      });		
                }	
              //	
                      });	
     
             
               return {testtype:testtype,id:id,statut:statut,type:type,description:description,priorite:priorite,version_correction:version_correction,progression:progression,totaux_exec_test:totaux_exec_test,taux_succes:taux_succes,exigence_id:exigence_id,etiquettes:etiquettes};
      }
      